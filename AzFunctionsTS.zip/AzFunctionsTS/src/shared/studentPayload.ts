export interface StudentPayload {
    FirstName: string;
    LastName: string;
    School: string;
}