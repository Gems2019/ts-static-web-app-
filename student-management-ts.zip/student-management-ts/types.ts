export interface Student {
  StudentId?: number;
  FirstName: string;
  LastName: string;
  School: string;
}
